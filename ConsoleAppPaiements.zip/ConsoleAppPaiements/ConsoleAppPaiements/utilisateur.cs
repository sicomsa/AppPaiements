﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppPaiements
{
    internal class utilisateur
    {
        public string Nom {  get; set; }
        public List<Paiement> paiements { get; set; } = new List<Paiement>();

        public utilisateur(string nom ) 

        { 
            Nom = nom;
        }
    }
}
